'use strict';

console.log('\'Allo \'Allo! Content script');
